//2015112120 임성두
package week4;

public class no2_map {

	int right;
	int down;
	
	public no2_map(int r,int d) {
		this.right=r;
		this.down=d;
	}
}
