//2015112120 임성두
package week5;

public class no1_map {

	int right;
	int down;
	int max=0;
	
	public no1_map(int r,int d) {
		this.right=r;
		this.down=d;
	}
}
