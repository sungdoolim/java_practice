//2015112120 임성두
package week6;

public class node {

	node left;
	node right;
	int value;
	node(){
		left=null;
		right=null;
		value=-1;
	}
}
